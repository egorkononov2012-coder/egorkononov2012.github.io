// Константы фигур и цветов
const SHAPES = [
    [[1]], 
    [[1,1]], 
    [[1,1,1]], 
    [[1,1,1,1]], 
    [[1,1],[1,1]], 
    [[1,1,1],[0,1,0]], 
    [[1,1,1],[1,1,1],[1,1,1]]
];
const COLORS = ['#FF5733', '#33FF57', '#3357FF', '#FF33A8', '#F39C12'];

// Переменные состояния игры
let gameMode = 'normal';
let timeLeft = 300; // 5 минут в секундах
let timerInterval;
let score = 0;
let savedData = null;
let draggedIdx = null;

// Сетка игры 8x8
let grid = Array(8).fill().map(() => Array(8).fill(0));
let gridColors = Array(8).fill().map(() => Array(8).fill(null));
let hand = [null, null, null];

// Рекорд из памяти телефона
let highScore = localStorage.getItem('blockBlastHighScore') || 0;

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('high-score-display').innerText = highScore;
    document.getElementById('high-score-text').innerText = "Рекорд: " + highScore;
    createBoard();
    setupTouchListeners();
});

// Создание визуальной сетки
function createBoard() {
    const board = document.getElementById('game-board');
    board.innerHTML = '';
    for(let y=0; y<8; y++) {
        for(let x=0; x<8; x++) {
            const c = document.createElement('div');
            c.className = 'cell';
            c.dataset.x = x;
            c.dataset.y = y;
            board.appendChild(c);
        }
    }
}

// Слушатели касаний для iPhone
function setupTouchListeners() {
    document.addEventListener('touchstart', (e) => {
        const box = e.target.closest('.piece-box');
        if (box) draggedIdx = parseInt(box.dataset.idx);
    });

    document.addEventListener('touchmove', (e) => {
        if (draggedIdx === null) return;
        e.preventDefault(); // Запрет прокрутки экрана
        const touch = e.touches[0];
        const elem = document.elementFromPoint(touch.clientX, touch.clientY);
        
        clearShadows();
        if (elem && elem.classList.contains('cell')) {
            showShadow(parseInt(elem.dataset.x), parseInt(elem.dataset.y));
        }
    }, {passive: false});

    document.addEventListener('touchend', (e) => {
        if (draggedIdx === null) return;
        const touch = e.changedTouches[0];
        const elem = document.elementFromPoint(touch.clientX, touch.clientY);
        
        if (elem && elem.classList.contains('cell')) {
            placePiece(parseInt(elem.dataset.x), parseInt(elem.dataset.y));
        }
        
        draggedIdx = null;
        clearShadows();
    });
}

// Показ тени перед установкой
function showShadow(tx, ty) {
    const piece = hand[draggedIdx];
    if(!piece) return;
    piece.shape.forEach((row, y) => row.forEach((val, x) => {
        if (val && ty+y < 8 && tx+x < 8) {
            const cell = document.querySelector(`[data-x="${tx+x}"][data-y="${ty+y}"]`);
            if (cell) cell.classList.add('preview');
        }
    }));
}

function clearShadows() {
    document.querySelectorAll('.cell').forEach(c => c.classList.remove('preview'));
}

// Установка блока на поле
function placePiece(tx, ty) {
    const piece = hand[draggedIdx];
    if(!piece) return;

    // Проверка: влезет ли фигура
    for(let y=0; y<piece.shape.length; y++) {
        for(let x=0; x<piece.shape[0].length; x++) {
            if(piece.shape[y][x]) {
                if(ty+y >= 8 || tx+x >= 8 || grid[ty+y][tx+x]) return;
            }
        }
    }

    // Запись в массив сетки
    piece.shape.forEach((row, y) => row.forEach((val, x) => {
        if(val) {
            grid[ty+y][tx+x] = 1;
            gridColors[ty+y][tx+x] = piece.color;
        }
    }));

    hand[draggedIdx] = null;
    score += 10;
    checkLines();
    if (hand.every(p => p === null)) generateHand();
    renderBoard();
    renderHand();
}

// Очистка линий и расчет очков
function checkLines() {
    let linesCleared = 0;
    // Горизонтальные линии
    for(let y=0; y<8; y++) {
        if(grid[y].every(c => c === 1)) {
            grid[y].fill(0);
            gridColors[y].fill(null);
            linesCleared++;
        }
    }
    // Вертикальные линии
    for(let x=0; x<8; x++) {
        let full = true;
        for(let y=0; y<8; y++) if(!grid[y][x]) full = false;
        if(full) {
            linesCleared++;
            for(let y=0; y<8; y++) {
                grid[y][x] = 0;
                gridColors[y][x] = null;
            }
        }
    }

    if(linesCleared > 0) {
        score += linesCleared * 100;
        if(score > highScore) {
            highScore = score;
            localStorage.setItem('blockBlastHighScore', highScore);
            document.getElementById('high-score-display').innerText = highScore;
        }
    }
    document.getElementById('score-display').innerText = score;
}

// Генерация новых блоков
function generateHand() {
    for(let i=0; i<3; i++) {
        hand[i] = {
            shape: SHAPES[Math.floor(Math.random()*SHAPES.length)],
            color: COLORS[Math.floor(Math.random()*COLORS.length)]
        };
    }
}

// Отрисовка поля
function renderBoard() {
    for(let y=0; y<8; y++) {
        for(let x=0; x<8; x++) {
            const cell = document.querySelector(`[data-x="${x}"][data-y="${y}"]`);
            cell.style.backgroundColor = gridColors[y][x] || '#1a1a1a';
        }
    }
}

// Отрисовка блоков в "руке"
function renderHand() {
    const cont = document.getElementById('pieces-container');
    cont.innerHTML = '';
    hand.forEach((p, i) => {
        const box = document.createElement('div');
        box.className = 'piece-box';
        box.dataset.idx = i;
        if(p) {
            box.style.gridTemplateColumns = `repeat(${p.shape[0].length}, 7vw)`;
            p.shape.forEach(row => row.forEach(val => {
                const c = document.createElement('div');
                c.className = 'mini-cell';
                if(val) c.style.backgroundColor = p.color;
                box.appendChild(c);
            }));
        }
        cont.appendChild(box);
    });
}

// Таймер для PRO режима
function updateTimer() {
    timeLeft--;
    let m = Math.floor(timeLeft/60).toString().padStart(2, '0');
    let s = (timeLeft%60).toString().padStart(2, '0');
    document.getElementById('timer-display').innerText = `${m}:${s}`;
    if(timeLeft <= 0) {
        clearInterval(timerInterval);
        alert("Время вышло!");
        saveAndGoToMenu();
    }
}

// Запуск игры
function startGame(mode, isNew) {
    gameMode = mode;
    if(isNew) {
        score = 0;
        timeLeft = 300;
        grid = Array(8).fill().map(() => Array(8).fill(0));
        gridColors = Array(8).fill().map(() => Array(8).fill(null));
        generateHand();
    }
    document.getElementById('score-display').innerText = score;
    document.getElementById('timer-display').style.display = (mode === 'pro') ? 'block' : 'none';
    
    if(mode === 'pro') {
        clearInterval(timerInterval);
        timerInterval = setInterval(updateTimer, 1000);
    }
    
    renderBoard();
    renderHand();
    document.getElementById('overlay').style.display = 'none';
}

// Проверка: начать заново или продолжить
window.checkAndStart = function(mode) {
    if(savedData && savedData.mode === mode) {
        document.getElementById('menu-buttons').innerHTML = `
            <button onclick="continueGame()">Продолжить</button>
            <button onclick="startGame('${mode}', true)">Новая игра</button>
        `;
    } else {
        startGame(mode, true);
    }
};

window.continueGame = function() {
    grid = savedData.grid;
    gridColors = savedData.gridColors;
    score = savedData.score;
    timeLeft = savedData.timeLeft;
    hand = savedData.hand;
    startGame(savedData.mode, false);
};

// Меню и Сохранение
window.saveAndGoToMenu = function() {
    clearInterval(timerInterval);
    savedData = {
        mode: gameMode,
        grid: JSON.parse(JSON.stringify(grid)),
        gridColors: JSON.parse(JSON.stringify(gridColors)),
        score: score,
        timeLeft: timeLeft,
        hand: JSON.parse(JSON.stringify(hand))
    };
    document.getElementById('overlay-title').innerText = "МЕНЮ";
    document.getElementById('menu-buttons').innerHTML = `
        <button onclick="checkAndStart('normal')">Normal</button>
        <button onclick="checkAndStart('pro')">Pro</button>
    `;
    document.getElementById('overlay').style.display = 'flex';
};